(async () => {
  const API_URL = "https://streampolyglot-hud-1044186749034.us-west1.run.app/translate";

  const box = document.createElement("div");
  box.style.cssText = `
    position:fixed;
    top:20px;
    right:20px;
    background:#111;
    color:#0f0;
    padding:12px;
    z-index:999999;
    font-family:monospace;
    min-width:260px;
  `;
  box.innerText = "Stream Polyglot iniciando...";
  document.body.appendChild(box);

  let i = 1;

  setInterval(async () => {
    const text = "Hello baby " + i++;
    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text })
      });
      const data = await res.json();
      box.innerText = text + " → " + data.translation;
    } catch (e) {
      box.innerText = "ERROR llamando backend";
    }
  }, 4000);
})();
